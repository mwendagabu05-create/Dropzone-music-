DropZone Music Android project

This is an Android Studio project wrapping the current HTML prototype in a WebView.
The prototype uses sample song listings. It does NOT yet connect to live music release feeds,
notifications, streaming providers, or download providers.

Build an APK:
1. Install Android Studio on a computer.
2. Open this DropZoneMusic folder as a project.
3. Allow Gradle sync and install any requested Android SDK components.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will be under app/build/outputs/apk/debug/app-debug.apk.

This project has not been compiled or tested here. No APK is included in this ZIP.
